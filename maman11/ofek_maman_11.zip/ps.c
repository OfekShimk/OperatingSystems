// Ofek Shimko 207336561

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
  ps161();

  exit();
}
